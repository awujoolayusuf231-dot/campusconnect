---
name: Collegiate Pulse
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1b1b1c'
  on-surface-variant: '#5c403d'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0ef'
  outline: '#906f6b'
  outline-variant: '#e5bdb9'
  surface-tint: '#bd1119'
  primary: '#b20112'
  on-primary: '#ffffff'
  primary-container: '#d62828'
  on-primary-container: '#fff1ef'
  inverse-primary: '#ffb4ab'
  secondary: '#b22835'
  on-secondary: '#ffffff'
  secondary-container: '#fe6066'
  on-secondary-container: '#640011'
  tertiary: '#006529'
  on-tertiary: '#ffffff'
  tertiary-container: '#008137'
  on-tertiary-container: '#d4ffd4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000d'
  secondary-fixed: '#ffdad8'
  secondary-fixed-dim: '#ffb3b2'
  on-secondary-fixed: '#410008'
  on-secondary-fixed-variant: '#900920'
  tertiary-fixed: '#7ffc97'
  tertiary-fixed-dim: '#62df7d'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005320'
  background: '#fcf9f8'
  on-background: '#1b1b1c'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
The design system channels the dynamism, academic rigor, and social energy of university life into a clean, modern digital ecosystem. Balancing professional institutional credibility with an inviting, peer-to-peer social atmosphere, the interface feels vibrant yet structured. The aesthetic combines modern minimalism with tactile, friendly surfaces—avoiding both cold enterprise rigidity and chaotic social media clutter.

Key attributes:
- **Tone:** Academic-forward, spirited, inclusive, reliable, and lively.
- **Visual Style:** Modern Collegiate Minimal—crisp white surfaces, deep crimson accents, soft background washes, generously rounded card architecture, and clear visual hierarchy.
- **Experience Goals:** Frictionless campus navigation, effortless discovery of clubs and events, high legibility under varying mobile lighting conditions, and intuitive privacy signaling across all interactions.

## Colors
The palette balances active collegiate reds against pristine neutrals and high-legibility text tiers to maintain focus and energy.

### Core Swatches
- **Primary Red (`#D62828`):** The vibrant anchor for focal actions, brand badges, and primary interactive highlights.
- **Deep Red (`#A61E2D`):** Rich crimson for active states, pressed interactive states, and high-contrast emphasis.
- **Soft Light Red (`#FDECEC`):** Tinted substrate for alert backdrops, active pill badges, and contextual tag highlights.
- **Soft Surface Neutral (`#F8F8F8`):** Canvas grounding layer providing soft contrast against elevated cards.
- **Crisp White (`#FFFFFF`):** High-clarity foreground for cards, sheets, headers, and navigation bars.
- **Dark Neutral (`#1F1F1F`):** Primary text and icon color providing AA/AAA compliant contrast.
- **Muted Secondary (`#6B7280`):** Secondary metadata, timestamps, helper text, and inactive tab states.
- **Subtle Border (`#E5E7EB`):** Structural divider lines and card outline definitions.
- **Success Green (`#16A34A`):** Verification status, confirmation banners, and RSVP accepts.
- **Warning Amber (`#F59E0B`):** Impending deadlines, alerts, and registration status flags.

### Application Rules
1. Background surfaces strictly use `#F8F8F8` for overall canvas and `#FFFFFF` for elevated modular cards.
2. Primary red is reserved for the primary CTA per view, notification dots, and key highlights; never oversaturate screen real estate with full-width red blocks.
3. Text must never fall below `#6B7280` on light backgrounds to preserve readability outdoors on campus.

## Typography
The system employs **Plus Jakarta Sans** for display, headings, and key structural labels to instill a modern, approachable geometric warmth. Body copy, metadata, input content, and dense data points leverage **Inter** for maximum optical legibility and clean line rhythm.

### Editorial Guidelines
- **Headlines:** Use Plus Jakarta Sans Bold with negative tracking (`-0.01em` to `-0.02em`) to produce tight, punchy feed headers and community titles.
- **Body:** Inter Regular provides high x-height clarity for rapid reading during fast feeds scanning.
- **Labels & Privacy Chips:** Inter Semi-Bold (`fontWeight: 600`) ensures micro-scale clarity inside badges, chips, and metadata indicators.

## Layout & Spacing
The layout model is built on an adaptable 8pt vertical rhythm, maintaining tight consistency across compact mobile viewports and multi-column desktop dashboards.

### Grid & Breakpoints
- **Mobile (up to 640px):** Single-column fluid stream. Canvas outer margin is `1rem` (`16px`). Components span full width between margins. Floating bottom navigation docked to safe area.
- **Tablet (641px - 1024px):** 8-column layout. Margin expands to `1.5rem` (`24px`). Split feed: primary content spans 5 columns, side widget / events rail spans 3 columns.
- **Desktop (1025px and up):** 12-column layout capped at `1280px` max-width. Margin expands to `2rem` (`32px`). Three-pane structure: Left navigation rail (3 columns), central interaction feed (6 columns), right campus utility rail (3 columns).

### Spacing Rules
- Element internal padding strictly relies on `space-sm` (8px) for chips/inputs, `space-md` (16px) for cards and modals, and `space-lg` (24px) for desktop card containers.
- Element stacking rhythm uses `space-md` for standard feed card separation and `space-xs` (4px) between title-to-metadata bindings.

## Elevation & Depth
Depth is created through clean surface layering and soft ambient drop shadows, preserving an airy, modern, clean paper feel rather than deep skeuomorphic distance.

### Depth Hierarchy
- **Level 0 (Base Canvas):** `#F8F8F8` flat fill. No elevation.
- **Level 1 (Feed Cards, List Rows, Content Blocks):** `#FFFFFF` fill supported by a 1px border of `#E5E7EB` and a diffuse ambient shadow: `0 1px 3px rgba(0, 0, 0, 0.04), 0 4px 8px rgba(0, 0, 0, 0.02)`.
- **Level 2 (Popovers, Dropdowns, Hovered Cards):** `#FFFFFF` fill with `0 8px 16px -2px rgba(31, 31, 31, 0.08)`.
- **Level 3 (Modal Sheets, Dialogs, Floating Navigation Bar):** `#FFFFFF` with `0 16px 32px -4px rgba(31, 31, 31, 0.12)`.
- **Bottom Navigation Bar:** Anchored at screen bottom with a subtle boundary blur: backdrop-filter blur 12px over `rgba(255, 255, 255, 0.9)` paired with a top border in `#E5E7EB`.

## Shapes
A friendly, modern, curvaceous shape language anchors this design system, using consistent organic radii to make campus navigation friendly and engaging.

### Radius Assignments
- **Feed Cards, Modals, Large Panels:** Apply `rounded-2xl` (`1rem` / `16px`) to achieve smooth, non-aggressive modular boundaries.
- **Action Buttons & Form Controls:** Base `0.5rem` (`8px`) to `0.75rem` (`12px`) for confident interactive targets.
- **Audience Privacy Indicators & Status Badges:** Strictly full-pill (`9999px`) to distinguish categorical tags from standard interactive cards.
- **Avatars:** Strictly circular (`rounded-full`) for individual students; soft squircle (`rounded-xl`) for university organizations, clubs, and academic departments.

## Components

### Buttons
- **Primary:** Background `#D62828`, text `#FFFFFF`, rounded 12px, font `Inter Semi-Bold`. Active/Pressed: `#A61E2D`. Focus ring: 2px offset with 2px stroke in `#D62828`. Height 44px (touch-friendly).
- **Secondary:** Background `#FDECEC`, text `#D62828`, border none, rounded 12px. Hover: background `#F9D5D5`.
- **Outline:** Background transparent, border 1px solid `#E5E7EB`, text `#1F1F1F`. Hover: background `#F8F8F8`.

### Privacy Badges & Scope Chips
Full-pill badges (`rounded-full`) with `label-sm` typography and inline micro-icons (12px) denoting visibility scope:
- **Public:** Gray subtle wash (`#F3F4F6`), text `#4B5563`, globe icon.
- **Followers Only:** Light blue wash (`#EFF6FF`), text `#1D4ED8`, user-check icon.
- **Institution Only:** Red tinted wash (`#FDECEC`), text `#D62828`, university building icon.
- **Community Only:** Amber wash (`#FEF3C7`), text `#D97706`, lock/shield icon.

### Cards (Feed & Events)
- Built on `#FFFFFF` with `rounded-2xl` (16px), 1px `#E5E7EB` border, and Level 1 elevation.
- Standard padding: `1rem` on mobile, `1.25rem` on tablet/desktop.
- Header row contains: Avatar, author name, institution/major info, privacy pill badge, and overflow action.
- Footer row includes tactile interactive icons (Like, Comment, Share, Bookmark) with counter numbers rendered in `Inter Medium` (`#6B7280`).

### Input Fields
- Height 44px, `rounded-xl` (10px), background `#FFFFFF`, border 1px solid `#E5E7EB`.
- Text color `#1F1F1F`, placeholder text `#6B7280`.
- Focus state: border-color `#D62828`, box-shadow `0 0 0 3px rgba(214, 40, 40, 0.12)`.
- Error state: border-color `#DC2626` accompanied by a micro error icon and caption.

### Lists & Activity Rows
- Clean borderless rows with `0.5rem` internal vertical spacing, separated by 1px `#E5E7EB` hairline dividers.
- Hover state: background `#F8F8F8` with a smooth 150ms ease transition.

### Checkboxes & Radio Buttons
- 20x20px dimension with 6px border radius (checkbox) or circular (radio).
- Default: 1.5px solid `#D1D5DB`, background `#FFFFFF`.
- Checked: Background `#D62828`, border-color `#D62828`, checkmark white `#FFFFFF`.

### Bottom Tab Bar Navigation (Mobile)
- Fixed bottom position, height 64px + safe area inset.
- Background: Translucent white (`rgba(255, 255, 255, 0.9)`) with 12px blur filter and `#E5E7EB` top border.
- Layout: 5 equal icon slots (Home, Communities, Create [+], Events, Profile).
- Active tab: `#D62828` icon color paired with a 4px primary-red dot indicator underneath.
- Inactive tabs: `#6B7280` icon color.
- Center Create action: elevated circular button (48px) with `#D62828` fill, white plus icon, and Level 2 drop shadow.