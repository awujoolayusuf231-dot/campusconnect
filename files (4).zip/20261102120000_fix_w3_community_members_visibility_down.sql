-- ROLLBACK for 20261102120000_fix_w3_community_members_visibility.sql. NEVER AUTO-RUN.
-- Restores the ORIGINAL policy. WARNING: this re-opens defect W3 (any signed-in user sees the uid of every active community member, including
-- private-profile users). Refuses unless the current policy is the W3 policy.
-- Run with: psql -v ON_ERROR_STOP=1 -f <this file>
begin;
do $$
declare v_qual text;
begin
  select p.qual into v_qual from pg_policies p where p.schemaname = 'public' and p.tablename = 'community_members' and p.policyname = 'community_members_select';
  if not found then raise exception 'ROLLBACK REFUSED: policy community_members_select does not exist'; end if;
  if v_qual !~* 'profiles' then raise exception 'ROLLBACK REFUSED: the policy is not the W3 policy (it does not reference profiles): %', v_qual; end if;
end $$;

drop policy community_members_select on public.community_members;
create policy community_members_select on public.community_members for select to authenticated using (
  user_id = (select auth.uid()) or (select public.has_permission('communities.manage'))
  or (status = 'active' and exists (select 1 from public.communities c where c.id = community_members.community_id)));
commit;
