-- ============================================================================
-- FIX W1: the shared visibility helper must apply the author's-profile rule to COMMUNITY posts too.
-- STATUS: PREPARED FOR REVIEW. NOT APPLIED anywhere. NOT executed (no PostgreSQL was available where this was written).
-- Requires migration A (it replaces A's public.internal_post_visible_to). Migrations A, B and C are NOT edited.
--
-- THE DEFECT: A's helper checked internal_profile_visible(author, viewer) only for ordinary posts. The existing row level security
-- (posts_select) checks it for EVERY post, because it contains exists (select 1 from profiles ...) and profiles_select enforces profile
-- visibility. So for community posts by a private or institution-only author the helper said "visible" where RLS says "not visible".
-- Effect on B: record_post_impressions would count community posts the caller cannot actually see (no data is disclosed, the function
-- returns nothing, but the author's analytics could be inflated). Effect on A: none (tag pages exclude community posts).
--
-- THE CHANGE: one condition. internal_profile_visible(p.author_id, p_viewer) now applies to ordinary AND community posts. Same name,
-- same signature, still SECURITY DEFINER with an empty search_path, so every caller keeps working and no grant changes (re-asserted below).
-- PRECONDITION: the current function must be exactly the text delivered in migration A (md5 of its source, CR characters ignored).
-- Rollback: supabase/rollbacks/20261102100000_fix_w1_visibility_helper_community_parity_down.sql
-- ============================================================================
do $$
declare v_md5 text;
begin
  select md5(replace(p.prosrc, E'\r', '')) into v_md5 from pg_proc p where p.oid = to_regprocedure('public.internal_post_visible_to(uuid,uuid)');
  if v_md5 is null then raise exception 'W1 requires migration A: public.internal_post_visible_to(uuid,uuid) does not exist'; end if;
  if v_md5 = '4d5b5995b06dbebe8d977690de098143' then raise exception 'W1 is already applied (the helper already has the new text)'; end if;
  if v_md5 <> '2a26b3c5c03f283ee78ba847a2754784' then raise exception 'W1 refused: internal_post_visible_to is not the text delivered in migration A (source md5 %). It was changed; review it before replacing.', v_md5; end if;
end $$;

create or replace function public.internal_post_visible_to(p_post uuid, p_viewer uuid) returns boolean
language sql stable security definer set search_path = '' as $$$
  select coalesce((
    select (
      p.status = 'visible'
      and coalesce(public.effective_status_internal(p.author_id) in ('active', 'restricted'), false)
      and not exists (select 1 from public.blocks b where b.blocker_id = p_viewer and b.blocked_id = p.author_id)
      and public.internal_profile_visible(p.author_id, p_viewer)
      and (p.community_id is null or exists (
            select 1 from public.communities c where c.id = p.community_id and c.status in ('active', 'archived')))
    )
    from public.posts p where p.id = p_post
  ), false)
$$$;

-- re-assert (idempotent): still not callable by any client role
revoke execute on function public.internal_post_visible_to(uuid, uuid) from public, anon, authenticated;
